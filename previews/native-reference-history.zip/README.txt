Original pre-label PCB screenshot, preserved byte-for-byte to keep the GitHub import under its size limit.
SHA-256 f77e45c4600eac2fec88cbd7bdac9ccc4377bd828c08d747a00a002ea29a09fa  native-labels-before-pcb.png
