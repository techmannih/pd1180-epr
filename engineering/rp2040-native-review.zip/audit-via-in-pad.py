import pcbnew, wx, json, hashlib
from pathlib import Path
app=wx.App(False)
p=Path('dist/manufacturing/kicad-project/pd1180-epr-r0.3.kicad_pcb'); b=pcbnew.LoadBoard(str(p))
pads=[(f.GetReference(),pad.GetNumber(),pad.GetEffectiveShape(pcbnew.F_Cu)) for f in b.GetFootprints() for pad in f.Pads() if pad.GetAttribute()==pcbnew.PAD_ATTRIB_SMD and pad.IsOnLayer(pcbnew.F_Paste)]
rows=[]
for v in b.GetTracks():
 if not isinstance(v,pcbnew.PCB_VIA): continue
 shape=pcbnew.SHAPE_CIRCLE(v.GetPosition(),v.GetDrillValue()//2)
 hits=[{'reference':ref,'pad':num} for ref,num,s in pads if s.Collide(shape,0)]
 if hits:rows.append({'uuid':v.m_Uuid.AsString(),'x_mm':v.GetPosition().x/1e6,'y_mm':v.GetPosition().y/1e6,'drill_mm':v.GetDrillValue()/1e6,'copper_diameter_mm':v.GetWidth(pcbnew.F_Cu)/1e6,'net':v.GetNetname(),'pads':hits})
r={'board_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'method':'Finished circular via drill intersects an F.Paste SMD land on the exact native PCB; all intersections require filled/capped processing.','count':len(rows),'process':'epoxy filled and copper capped','fabricator_accepted':False,'vias':sorted(rows,key=lambda v:(v['x_mm'],v['y_mm']))}
Path('engineering/rp2040-via-in-pad.json').write_text(json.dumps(r,indent=2)+'\n');print(len(rows), sorted({p['reference'] for r in rows for p in r['pads']}))
