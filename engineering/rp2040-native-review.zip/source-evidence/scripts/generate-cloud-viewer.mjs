import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { readFileSync } from 'node:fs'
import { basename } from 'node:path'
import { isDeepStrictEqual } from 'node:util'
import { KicadToCircuitJsonConverter } from 'kicad-to-circuit-json'
import { parseKicadPcb } from 'kicadts'

const DEFAULT_SOURCE = 'dist/index/circuit.json'
const DEFAULT_ASSEMBLY = 'dist/motor-assembly/circuit.json'
const DEFAULT_BOARD = 'dist/manufacturing/kicad-project/pd1180-epr-r0.3.kicad_pcb'
const DEFAULT_OUTPUT = 'release/circuit.json'

function groupCounts(circuit) {
  return Object.fromEntries(
    Object.entries(Object.groupBy(circuit, (element) => element.type))
      .map(([type, elements]) => [type, elements.length]),
  )
}

function portKey(componentName, pinNumber) {
  return `${componentName}:${String(pinNumber)}`
}

// KiCad coordinates use nanometres. Remove subtraction noise introduced when
// the converter recentres them, without rounding genuinely finer coordinates.
function copyCopperCoordinates(value, key) {
  if (typeof value === 'number' && (key === 'x' || key === 'y')) {
    const native = Math.round(value * 1e6) / 1e6
    const noise = Number.EPSILON * Math.max(1, Math.abs(value)) * 8
    return Math.abs(native - value) <= noise ? native : value
  }
  if (Array.isArray(value)) return value.map(item => copyCopperCoordinates(item))
  if (value && typeof value === 'object')
    return Object.fromEntries(Object.entries(value).map(([name, item]) => [name, copyCopperCoordinates(item, name)]))
  return value
}

export async function createCloudViewerCircuit({
  sourceCircuitPath = DEFAULT_SOURCE,
  routedBoardPath = DEFAULT_BOARD,
  assemblyCircuitPath = DEFAULT_ASSEMBLY,
} = {}) {
  const sourceCircuit = JSON.parse(await readFile(sourceCircuitPath, 'utf8'))
  const assemblyCircuit = JSON.parse(await readFile(assemblyCircuitPath, 'utf8'))
  const mechanicalIds = assertAssemblyPreservesBoard(sourceCircuit, assemblyCircuit)
  const nativeText = await readFile(routedBoardPath, 'utf8')
  assertNativePackagePinsMatch(sourceCircuit, nativeText)
  const converter = new KicadToCircuitJsonConverter()
  converter.addFile(basename(routedBoardPath), nativeText)
  converter.runUntilFinished()
  const routedCircuit = converter.getOutput()

  const result = combineSourceAndRoutedCircuit(assemblyCircuit, routedCircuit)
  return {
    ...result,
    report: {
      ...result.report,
      source_circuit: sourceCircuitPath,
      assembly_circuit: assemblyCircuitPath,
      mechanical_source_ids: mechanicalIds,
      board_records_preserved: true,
      routed_board: routedBoardPath,
      converter_warnings: converter.getWarnings(),
    },
  }
}

// Reject an obsolete architecture before an expensive full copper import. This
// does not qualify the route: the existing net, port and geometry checks follow.
export function assertNativePackagePinsMatch(source, nativeText) {
  const names = new Map(source.filter(r=>r.type==='source_component').map(r=>[r.source_component_id,r.name]))
  const pins = new Map()
  for(const port of source.filter(r=>r.type==='source_port')) {
    const name=names.get(port.source_component_id)
    if(!pins.has(name)) pins.set(name,new Set())
    pins.get(name).add(String(port.pin_number))
  }
  const seen=new Set()
  for(const fp of parseKicadPcb(nativeText).footprints) {
    const name=fp.properties.find(p=>p.key==='Reference')?.value
    if(!name) continue // non-component mounting holes
    if(!pins.has(name)) throw new Error(`Native board contains removed component ${name}; regenerate routing before publishing`)
    const actual=[...new Set(fp.fpPads.map(p=>String(p.number)).filter(Boolean))].sort()
    const expected=[...pins.get(name)].sort()
    if(!isDeepStrictEqual(actual,expected)) throw new Error(`Native ${name} package pins differ from source; regenerate routing before publishing`)
    seen.add(name)
  }
  for(const name of pins.keys()) if(!seen.has(name)) throw new Error(`Native board is missing ${name}; regenerate routing before publishing`)
}

// Every selectable mechanical part must be declared in the generated manifest.
// Electrical, schematic and PCB records must still match the board exactly.
export function assertAssemblyPreservesBoard(board, assembly) {
  const mechanical = assembly.filter(row => row.type === 'source_component' && row.ftype === 'subassembly')
  const expected = JSON.parse(readFileSync('engineering/mechanical/assembly-parts.json', 'utf8')).map(p => p.name).sort()
  if (!isDeepStrictEqual(mechanical.map(row => row.name).sort(), expected))
    throw new Error('Hosted assembly differs from the explicit mechanical parts manifest')
  const ids = new Set(mechanical.map(row => row.source_component_id))
  for (const id of ids) {
    const models = assembly.filter(row => row.type === 'cad_component' && row.source_component_id === id)
    if (models.length !== 1 || !models[0].model_glb_url)
      throw new Error(`Missing mechanical CAD model for ${id}`)
  }
  const withoutCacheKey = rows => rows.map(row => {
    if (row.type !== 'source_project_metadata') return row
    const { source_filesystem_md5_hash, ...metadata } = row
    return metadata
  })
  const boardOnly = assembly.filter(row => !(ids.has(row.source_component_id) && ['source_component', 'cad_component'].includes(row.type)))
  if (!isDeepStrictEqual(withoutCacheKey(boardOnly), withoutCacheKey(board)))
    throw new Error('Assembly changed the verified board records; rebuild both source entrypoints')
  return [...ids]
}

export function combineSourceAndRoutedCircuit(sourceCircuit, routedCircuit) {
  const sourceNetsByName = new Map(sourceCircuit
    .filter((element) => element.type === 'source_net')
    .map((net) => [net.name, net]))
  const sourceTraceByNetId = new Map()
  for (const trace of sourceCircuit.filter((element) => element.type === 'source_trace')) {
    for (const netId of trace.connected_source_net_ids || []) {
      if (!sourceTraceByNetId.has(netId)) sourceTraceByNetId.set(netId, trace.source_trace_id)
    }
  }
  const routedNets = new Map(routedCircuit
    .filter((element) => element.type === 'source_net')
    .map((net) => [net.source_net_id, net]))
  const routedTraces = new Map(routedCircuit
    .filter((element) => element.type === 'source_trace')
    .map((trace) => [trace.source_trace_id, trace]))
  const namedCopperCounts = { pcb_trace: 0, pcb_via: 0, pcb_copper_pour: 0 }
  const routedNetNames = new Set()

  function resolveSourceNet(element) {
    const trace = routedTraces.get(element.source_trace_id)
    const names = new Set([
      element.net_name,
      routedNets.get(element.source_net_id)?.name,
      ...(trace?.connected_source_net_ids || []).map((id) => routedNets.get(id)?.name),
    ].filter(Boolean))
    if (names.size !== 1) throw new Error(`${element.type}: expected one named routed net, found ${[...names].join(', ') || 'none'}`)
    const [name] = names
    const sourceNet = sourceNetsByName.get(name)
    if (!sourceNet) throw new Error(`${element.type}: routed net ${name} is absent from the source circuit`)
    namedCopperCounts[element.type]++
    routedNetNames.add(name)
    return sourceNet
  }

  const sourceComponents = new Map(
    sourceCircuit
      .filter((element) => element.type === 'source_component')
      .map((element) => [element.source_component_id, element]),
  )
  const sourcePorts = new Map(
    sourceCircuit
      .filter((element) => element.type === 'source_port')
      .map((element) => [element.source_port_id, element]),
  )
  const basePcbComponents = new Map(
    sourceCircuit
      .filter((element) => element.type === 'pcb_component')
      .map((element) => [element.pcb_component_id, element]),
  )
  const basePortByKey = new Map()
  for (const pcbPort of sourceCircuit.filter((element) => element.type === 'pcb_port')) {
    const sourcePort = sourcePorts.get(pcbPort.source_port_id)
    const pcbComponent = basePcbComponents.get(pcbPort.pcb_component_id)
    const sourceComponent = sourceComponents.get(pcbComponent?.source_component_id)
    if (!sourcePort || !sourceComponent) continue
    basePortByKey.set(portKey(sourceComponent.name, sourcePort.pin_number), pcbPort)
  }

  const routedSourceComponents = new Map(
    routedCircuit
      .filter((element) => element.type === 'source_component')
      .map((element) => [element.source_component_id, element]),
  )
  const routedPcbComponents = new Map(
    routedCircuit
      .filter((element) => element.type === 'pcb_component')
      .map((element) => [element.pcb_component_id, element]),
  )
  const routedPortToBasePort = new Map()
  for (const routedPort of routedCircuit.filter((element) => element.type === 'pcb_port')) {
    const pcbComponent = routedPcbComponents.get(routedPort.pcb_component_id)
    const sourceComponent = routedSourceComponents.get(pcbComponent?.source_component_id)
    const pinMatch = routedPort.source_port_id?.match(/_port_(.+)$/)
    if (!sourceComponent || !pinMatch) continue
    const basePort = basePortByKey.get(portKey(sourceComponent.name, pinMatch[1]))
    if (basePort) routedPortToBasePort.set(routedPort.pcb_port_id, basePort)
  }

  const importedTypes = new Set(['pcb_trace', 'pcb_via', 'pcb_copper_pour'])
  const circuit = sourceCircuit.filter((element) => !importedTypes.has(element.type)).map((element) => {
    if (element.type !== 'source_project_metadata') return element
    // CLI 0.0.2774 hashes reports and release/circuit.json into its local build
    // cache key. Publishing that key creates a self-referential, changing hash.
    // It is not circuit data or release provenance: the routing fingerprint,
    // verified-input SHA-256 and delivery manifest provide those checks.
    const { source_filesystem_md5_hash, ...metadata } = element
    return metadata
  })
  let attributedTraceCount = 0
  const attributedSourceTraces = new Set()

  for (const [index, imported] of routedCircuit.filter((element) => element.type === 'pcb_trace').entries()) {
    const trace = copyCopperCoordinates(imported)
    trace.pcb_trace_id = `pcb_trace_cloud_routed_${index}`
    trace.subcircuit_id = 'subcircuit_source_group_0'
    const sourceNet = resolveSourceNet(imported)
    const sourceTraceId = sourceTraceByNetId.get(sourceNet.source_net_id)
    if (!sourceTraceId) throw new Error(`No source trace connects named net ${sourceNet.name}`)
    for (const point of trace.route || []) {
      for (const endpointField of ['start_pcb_port_id', 'end_pcb_port_id']) {
        if (!point[endpointField]) continue
        const basePort = routedPortToBasePort.get(point[endpointField])
        if (basePort) {
          point[endpointField] = basePort.pcb_port_id
        } else {
          delete point[endpointField]
        }
      }
    }
    trace.source_trace_id = sourceTraceId
    attributedTraceCount += 1
    attributedSourceTraces.add(sourceTraceId)
    circuit.push(trace)
  }

  for (const [index, imported] of routedCircuit.filter((element) => element.type === 'pcb_via').entries()) {
    const via = copyCopperCoordinates(imported)
    via.pcb_via_id = `pcb_via_cloud_routed_${index}`
    via.subcircuit_id = 'subcircuit_source_group_0'
    via.source_net_id = resolveSourceNet(imported).source_net_id
    delete via.source_trace_id
    delete via.pcb_port_ids
    circuit.push(via)
  }
  for (const [index, imported] of routedCircuit.filter((element) => element.type === 'pcb_copper_pour').entries()) {
    const pour = copyCopperCoordinates(imported)
    pour.pcb_copper_pour_id = `pcb_copper_pour_cloud_routed_${index}`
    pour.subcircuit_id = 'subcircuit_source_group_0'
    pour.source_net_id = resolveSourceNet(imported).source_net_id
    circuit.push(pour)
  }

  const sourceCounts = groupCounts(sourceCircuit)
  const routedCounts = groupCounts(routedCircuit)
  const outputCounts = groupCounts(circuit)
  return {
    circuit,
    report: {
      schema_version: 1,
      mapped_pcb_ports: routedPortToBasePort.size,
      imported_pcb_ports: routedCounts.pcb_port || 0,
      attributed_pcb_traces: attributedTraceCount,
      attributed_source_traces: attributedSourceTraces.size,
      named_copper_counts: namedCopperCounts,
      routed_net_names: [...routedNetNames].sort(),
      source_counts: sourceCounts,
      routed_board_counts: routedCounts,
      cloud_viewer_counts: outputCounts,
    },
  }
}

export async function writeCloudViewerCircuit({
  outputPath = DEFAULT_OUTPUT,
  reportPath = 'docs/cloud-viewer-check.json',
  ...options
} = {}) {
  const result = await createCloudViewerCircuit(options)
  await mkdir('release', { recursive: true })
  await writeFile(outputPath, `${JSON.stringify(result.circuit)}\n`)
  if (reportPath) {
    await mkdir('docs', { recursive: true })
    await writeFile(reportPath, `${JSON.stringify({ ...result.report, errors: [] }, null, 2)}\n`)
  }
  return result
}

if (import.meta.main) {
  const { report } = await writeCloudViewerCircuit()
  console.log(JSON.stringify(report, null, 2))
}
