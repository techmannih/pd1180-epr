# Fresh website KiCad download recheck — 2026-10-27

## Result

The user’s new website download is **not stale**. GitHub main is `952de54ca0b5dbe042d9ccc9a1a9ecf3e8f67779` (merged PR #13). Active website release **0.3.95**, ID `a170e23e-c799-422d-b275-db5267c84ddf`, identifies that commit. Its source, routed JSON and release hash manifest match the tested PR files; built routed JSON is structurally identical despite formatting. The user’s PCB hash is `4fe7e26213f0505aa17d26742f1a5e3f3d35fcdd977ffd1032c53cf1c6560d69`.

All **6,103 routed segments** match the corrected native board exactly, including their net, layer, width and endpoints. The previous undersized-track/inter-net-clearance errors are gone. Nevertheless, the generic website KiCad export is not equivalent to the native release project.

The previous verification covered the native project. It did **not** complete the end-to-end website-download check. Both paths have now been freshly checked with KiCad 10.0.5 on copies; the original download and repository are unchanged.

| Check | Errors | Warnings | Unconnected | Schematic parity |
| --- | ---: | ---: | ---: | --- |
| New download, same options as the user’s GUI | 17 | 641 | 0 | Not requested |
| New download, all track errors + parity | 25 | 641 | 0 | 604 findings |
| Native PR #13 release, all track errors + parity | 0 | 401 | 0 | 0 |
| Diagnostic download copy, only global edge rule restored to native 0.20 mm | 0 | 641 | 0 | Not requested |

All runs refill zones and retain all severities. The 25 expanded errors are the same copper-edge category, with additional per-track findings; they are not 25 additional errors on top of the GUI count.

## Why it fails

1. **Global copper-edge rule is lost in project export.** Routed Circuit JSON carries `min_board_edge_clearance: 0.2`; native project uses 0.20 mm. The generic project converter examined in this investigation omits its mapping, and the downloaded/opened KiCad project uses the 0.50 mm default. The requested **0.50 mm GND-pour inset is a separate rule**, not the global distance for every signal/power track. For example, a GND track 0.4453 mm from Edge.Cuts fails 0.50 mm. Restoring only this global field on a diagnostic copy clears all 17 GUI-equivalent errors without changing copper. That is causal evidence, not approval to fabricate or suppress remaining findings.
2. **Zone policy/keepouts are not preserved.** The native PCB has 24 rule areas plus 82 copper zones. The download has 101 split copper polygons, zero rule areas, and uniform 0.15 mm zone clearance / 0.25 mm minimum thickness. Native GND zones have 0.30 mm clearance; power zones have their separately reviewed settings. The repository adapter imports only traces/vias/pours; its published pour records lack the native zone policy. The generic converter also hardcodes the observed defaults. Exact filled-copper/current-path equivalence after re-export/refill is not certified.
3. **Seven duplicate CC vias are exported.** Native has 643 vias; download has 650, comprising the same 643 unique geometries plus seven duplicates. This explains the seven co-located-hole warnings.
4. **Other export/mapping warnings remain.** Download has 199 unresolved `tscircuit` footprint-library references, a new 0.064 mm V3V3 dangling-track warning, one silk-edge warning and additional silk overlap/over-copper findings. The native’s 401 cosmetic warnings remain visible. The extra dangling warning’s detailed local-fill cause is not yet isolated.
5. **Schematic association is inconsistent.** Full export parity reports 199 footprint, 199 field and 199 net-mapping mismatches, three duplicate-footprint references and four extra footprints. These are schematic/PCB association findings, not evidence of 604 physical shorts. Native parity is zero.

The examined local converter versions reproduce these export behaviours; the exact converter build deployed by the website has not been established from version labels alone.

## Where the fix belongs

- This repository’s `scripts/generate-cloud-viewer.mjs`: preserve native zone/keepout information and explicit net identity through its native-to-Circuit-JSON adapter, and validate actual round-trip output.
- `circuit-json-to-kicad`: map global edge and other project constraints, preserve per-zone settings and resolve the duplicate-via/schematic association cases. `kicad-to-circuit-json` must retain native rule-area/pour metadata instead of dropping it.
- Add an acceptance check on the **actual website-downloaded project**, including refill, all-track DRC, parity and geometry/critical-copper comparison. A source build or native-only report is insufficient for this download path.

Do not reduce the requested 0.15 mm track width, 0.30 mm GND clearance or 0.50 mm GND inset to make checks pass. A global edge-only adjustment does not repair all export losses. The native release ZIP remains the matching review artifact, with its existing sourcing, cosmetic and hardware qualification holds.

## Evidence

- [Compact machine summary](audit-summary.json)
- [Fresh download DRC matching the GUI](download-gui-drc.json)
- [Expanded download DRC and parity](download-full-drc.json)
- [Fresh native DRC and parity](native-full-drc.json)
- [Edge-only diagnostic DRC](edge-only-drc.json)
- [Geometry comparison](geometry-comparison.json)
- [Website versus PR content comparison](published-comparison.json)

No original PCB, project rule or repository source was changed by this investigation.
